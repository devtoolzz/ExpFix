#include <iostream>
#include <cstdlib> // do generowania losowych numerów

using namespace std;

// Klasa reprezentująca aplikację
class Application {
private:
    string name;

public:
    Application(string appName) : name(appName) {}

    // Metoda do otwierania aplikacji
    void open() {
        cout << "Opening " << name << "..." << endl;
        // Symulacja losowej szansy na wystąpienie błędu
        int randomError = rand() % 5; // Wygenerowanie losowej liczby od 0 do 4
        if (randomError == 0) {
            cout << "Error: " << name << " has encountered a problem." << endl;
        } else {
            cout << name << " is now open!" << endl;
        }
    }
};

int main() {
    // Inicjalizacja generatora liczb pseudolosowych
    srand(time(NULL));

    // Tworzenie trzech różnych aplikacji
    Application app1("App 1");
    Application app2("App 2");
    Application app3("App 3");

    // Otwieranie aplikacji
    app1.open();
    app2.open();
    app3.open();

    return 0;
}
