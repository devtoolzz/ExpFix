#include <iostream>
#include <cstdlib> // do generowania losowych numerów

using namespace std;

// Klasa reprezentująca aplikację
class Application {
private:
    string name;

public:
    Application(string appName) : name(appName) {}

    // Metoda do otwierania aplikacji
    void open() {
        cout << "Opening " << name << "..." << endl;
        // Symulacja losowej szansy na wystąpienie błędu
        int randomError = rand() % 5; // Wygenerowanie losowej liczby od 0 do 4
        if (randomError == 0) {
            cout << "Error: " << name << " has encountered a problem." << endl;
        } else {
            cout << name << " is now open!" << endl;
        }
    }

    // Metoda do naprawiania aplikacji
    void fix() {
        cout << "Fixing " << name << "..." << endl;
        cout << "Fixed " << name << " successfully!" << endl;
    }

    // Metoda do szukania błędów w aplikacji
    void searchForError() {
        cout << "Searching for errors in " << name << "..." << endl;
        cout << "No errors found in " << name << "." << endl;
    }
};

int main() {
    // Inicjalizacja generatora liczb pseudolosowych
    srand(time(NULL));

    // Tworzenie sześciu różnych aplikacji
    Application app1("App 1");
    Application app2("App 2");
    Application app3("App 3");
    Application app4("App 4");
    Application app5("App 5");
    Application app6("App 6");

    // Otwieranie, naprawianie i szukanie błędów w aplikacjach
    app1.open();
    app2.fix();
    app3.searchForError();
    app4.open();
    app5.fix();
    app6.searchForError();

    return 0;
}
