#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

// Klasa reprezentująca gracza
class Player {
private:
    string name;
    int health;
    int damage;

public:
    Player(string playerName) : name(playerName), health(100), damage(20) {}

    // Metoda do ataku
    void attack(Player& target) {
        cout << name << " attacks " << target.getName() << "!" << endl;
        target.takeDamage(damage);
    }

    // Metoda do przyjęcia obrażeń
    void takeDamage(int dmg) {
        health -= dmg;
        cout << name << " took " << dmg << " damage!" << endl;
        if (health <= 0) {
            cout << name << " has been defeated!" << endl;
        }
    }

    // Metoda sprawdzająca czy gracz jest nadal w grze
    bool isAlive() {
        return health > 0;
    }

    string getName() {
        return name;
    }
};

int main() {
    // Inicjalizacja generatora liczb pseudolosowych
    srand(time(NULL));

    // Stworzenie dwóch graczy
    Player player1("Player 1");
    Player player2("Player 2");

    // Rozgrywka
    while (player1.isAlive() && player2.isAlive()) {
        // Gracz 1 atakuje gracza 2
        player1.attack(player2);
        // Sprawdzenie czy gracz 2 nadal żyje po ataku
        if (!player2.isAlive()) {
            break;
        }
        // Gracz 2 atakuje gracza 1
        player2.attack(player1);
        // Sprawdzenie czy gracz 1 nadal żyje po ataku
        if (!player1.isAlive()) {
            break;
        }
    }

    // Sprawdzenie wyniku
    if (player1.isAlive()) {
        cout << player1.getName() << " wins!" << endl;
    } else if (player2.isAlive()) {
        cout << player2.getName() << " wins!" << endl;
    } else {
        cout << "It's a tie!" << endl;
    }

    return 0;
}
